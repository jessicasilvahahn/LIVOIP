#!/bin/bash
 
start() {
  echo 'Trying start service!'
  /opt/tools/Python-3.6.7/bin/python3 /opt/ali/module_adm.pyc -c /opt/ali/conf/adm_rm.conf

}                                                                                                                                                                        
                                                                                                                                                                            
start