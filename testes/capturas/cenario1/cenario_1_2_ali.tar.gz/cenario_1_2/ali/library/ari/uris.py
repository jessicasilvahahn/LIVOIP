#!/opt/li-asterisk/tools/Python-3.6.7

#Lista de URIS que serao utilizadas
LIST_CHANNELS = "{}/ari/channels"
LIST_RECORDS = "{}/ari/recordings/stored"
GET_RECORD = "{}/ari/recordings/stored/{}/file"
GET_PCAP = "{}/ari/recordings/stored/pcap"
ADD_INTERCEPTION = "{}/ari/interception/add"
INACTIVE_INTERCEPTION = "{}/ari/interception/inactive"
GET_IRI = "{}/ari/recordings/iri/"
GET_CC = "{}/ari/recordings/cc/"